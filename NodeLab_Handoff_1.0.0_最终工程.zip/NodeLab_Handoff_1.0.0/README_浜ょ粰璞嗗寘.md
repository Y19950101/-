这是 NodeLab 项目交接包。

请先阅读“豆包制作IPA指令.txt”，然后以当前目录中的 Xcode 工程为基础继续完善，不要重新从零设计。

注意：IPA 签名需要开发者证书/Provisioning Profile；没有这些时只能输出未签名 Xcode 工程或 Archive，不要伪造已签名 IPA。
