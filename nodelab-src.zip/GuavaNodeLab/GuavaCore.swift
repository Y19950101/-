//
//  GuavaCore.swift
//  Node Lab
//
//  实现层：客户端常量、Keychain、设备身份、客户端签名、AES、HTTP、
//  业务信封解析、API 编排与节点解析。
//
//  所有端点 / 请求头 / 响应信封结构均来自对《番石榴-1.0.3.ipa》的
//  静态逆向分析 + 在线实测（见 README「分析结论」章节）。
//

import Foundation
import CommonCrypto
import Security

// MARK: - 客户端常量（唯一需要按需修改的位置）

enum ClientConfig {
    /// 原 App 的 API 配置入口（逆向提取，已实测可用）
    static let apiConfigURLs: [String] = [
        "https://raw.githubusercontent.com/Faalemon/cloud/main/api-1011fsl.json",
        "https://api.ibale.cc/s3c/api-1011fsl.json",
        "https://cts.ibl1.site:31011/s3c/api-1011fsl.json",
        "https://ibale.lat/s3c/api-1011fsl.json"
    ]

    /// X-Client-Agent-Flag 取值（逆向确认该请求头名，值为平台标识）
    static let agentFlag = "ios"

    /// X-Client-Language 取值
    static let clientLanguage = "zh-CN"

    /// 配置返回中的 API 根字段
    static let configRootKeys = ["api_url1", "api_url2"]
    static let configCloudKeys = ["cloud_url", "cloud_url_f1", "cloud_url_f2"]

    /// ⚠️ 客户端签名常量（X-Client-App-Token）
    ///
    /// 原 App 在 Encrypt.generateAppToken() 中生成该值，服务端校验。
    /// 静态逆向未能从二进制中直接恢复明文密钥（十六进制串 "MinghuaQu"
    /// 经比对为 pointycastle 椭圆曲线参数，并非密钥）。
    ///
    /// 当前官方服务端对所有缺少有效 X-Client-App-Token 的请求统一返回
    /// code=30003「版本过低请升级」。要启用官方 API 通道，需要把下方
    /// appKey / aesKey 替换为**你自己设备上官方当前版本**的常量：
    ///
    ///   1) 用抓包工具（如 Stream / Charles / mitmproxy）代理你手机上
    ///      官方 App 的流量（使用你自己的合法账号）；
    ///   2) 从 https://api.ibale.cc 的请求中复制 X-Client-App-Token；
    ///   3) 由于该 Token 含时间戳、每次不同，真正需要的是**生成它的
    ///      密钥**。请在装有 Linux/WSL 的机器上用 blutter 反编译官方
    ///      当前版本 IPA（App.framework/App），在 Encrypt 类里直接读
    ///      _aesKey / _appKey 的取值（README 附详细步骤）；
    ///   4) 把读到的值填到下面两行即可，其余代码无需改动。
    ///
    /// 留空时 App 不发送 X-Client-App-Token（等效于旧版本客户端），
    /// 服务端会返回 30003，App 会如实显示该错误与官方升级地址。
    /// 我们不做任何伪造版本 / 伪造设备 / 绕过授权的尝试。
    static let appKey = ""   // TODO: 官方当前版本 Encrypt._appKey
    static let aesKey = ""   // TODO: 官方当前版本 Encrypt._aesKey（16 或 32 字节）

    static var hasClientCredentials: Bool {
        !appKey.isEmpty && !aesKey.isEmpty
    }
}

// MARK: - Keychain（保存用户自己的合法授权信息）

final class KeychainStore {
    static let shared = KeychainStore()

    private let service: String

    init(service: String? = nil) {
        self.service = service ?? (Bundle.main.bundleIdentifier ?? "com.gnlab.NodeLab")
    }

    // 登录 Token（X-Client-Token）
    var authToken: String? {
        get { get("auth_token") }
        set {
            if newValue == nil {
                delete("auth_token")
            } else {
                set(newValue!, key: "auth_token")
            }
        }
    }

    // 用户邮箱（用于 Token 过期自动重登）
    var email: String? {
        get { get("email") }
        set {
            if newValue == nil {
                delete("email")
            } else {
                set(newValue!, key: "email")
            }
        }
    }

    // 用户自己的密码（仅用于自动重登，Keychain 加密保存）
    var password: String? {
        get { get("password") }
        set {
            if newValue == nil {
                delete("password")
            } else {
                set(newValue!, key: "password")
            }
        }
    }

    // 本 App 的设备 ID（首次生成后持久化）
    var deviceId: String? {
        get { get("device_id") }
        set {
            if newValue == nil {
                delete("device_id")
            } else {
                set(newValue!, key: "device_id")
            }
        }
    }

    func clearAuth() {
        authToken = nil
        email = nil
        password = nil
    }

    // MARK: - 私有读写

    @discardableResult
    private func set(_ value: String, key: String) -> Bool {
        let data = Data(value.utf8)
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: key
        ]
        SecItemDelete(query as CFDictionary)
        var attrs = query
        attrs[kSecValueData as String] = data
        attrs[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        return SecItemAdd(attrs as CFDictionary, nil) == errSecSuccess
    }

    private func get(_ key: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: key,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var item: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &item) == errSecSuccess,
              let data = item as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    private func delete(_ key: String) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: key
        ]
        SecItemDelete(query as CFDictionary)
    }
}

// MARK: - 设备身份（本 App 自己的持久化设备 ID，不做任何伪造）

enum DeviceIdentity {
    static var deviceId: String {
        if let cached = KeychainStore.shared.deviceId, !cached.isEmpty {
            return cached
        }
        let id = UUID().uuidString.lowercased()
        KeychainStore.shared.deviceId = id
        return id
    }
}

// MARK: - AES-CBC（与原始 App 相同的加密组件：AES/CBC + PKCS7 + Base64）

enum AESCryptor {
    static func aesEncrypt(_ plain: String, key: String, iv: String) -> String? {
        guard !plain.isEmpty, !key.isEmpty else { return nil }
        let keyBytes = [UInt8](key.utf8)
        let ivBytes = [UInt8](iv.utf8)
        guard ivBytes.count >= kCCBlockSizeAES128, let plainData = plain.data(using: .utf8) else {
            return nil
        }
        let keySize: Int
        switch keyBytes.count {
        case 16: keySize = kCCKeySizeAES128
        case 24: keySize = kCCKeySizeAES192
        default: keySize = kCCKeySizeAES256
        }
        var out = [UInt8](repeating: 0, count: plainData.count + kCCBlockSizeAES128)
        var outLen = 0
        let status = keyBytes.withUnsafeBytes { kp in
            ivBytes.withUnsafeBytes { ip in
                plainData.withUnsafeBytes { pp in
                    CCCrypt(CCOperation(kCCEncrypt),
                            CCAlgorithm(kCCAlgorithmAES),
                            CCOptions(kCCOptionPKCS7Padding),
                            kp.baseAddress, keySize,
                            ip.baseAddress,
                            pp.baseAddress, plainData.count,
                            &out, out.count, &outLen)
                }
            }
        }
        guard status == kCCSuccess else { return nil }
        return Data(out.prefix(outLen)).base64EncodedString()
    }
}

// MARK: - 客户端签名（X-Client-App-Token）

enum ClientSigner {
    /// 生成 X-Client-App-Token。
    /// 结构按原 App 的 Encrypt.generateAppToken() 实现：
    ///   payload = appKey + "&" + unix时间戳
    ///   token   = base64( AES-CBC( key: aesKey, iv: aesKey 前 16 字节, data: payload ) )
    /// 若你从官方当前版本提取到的实际算法不同，只需修改本方法。
    static func appToken() -> String? {
        guard ClientConfig.hasClientCredentials else { return nil }
        let time = String(Int(Date().timeIntervalSince1970))
        let payload = "\(ClientConfig.appKey)&\(time)"
        let iv = String(ClientConfig.aesKey.prefix(16))
        return AESCryptor.aesEncrypt(payload, key: ClientConfig.aesKey, iv: iv)
    }
}

// MARK: - 业务信封

struct GuavaEnvelope {
    let code: Int
    let message: String
    let data: Any?
    let exceptionData: Any?

    static func parse(_ data: Data) -> GuavaEnvelope? {
        guard let json = try? JSONSerialization.jsonObject(with: data),
              let dict = json as? [String: Any] else { return nil }
        let code = (dict["code"] as? Int) ?? (dict["code"] as? NSNumber)?.intValue ?? -1
        let message = (dict["message"] as? String) ?? ""
        return GuavaEnvelope(code: code,
                             message: message,
                             data: dict["data"],
                             exceptionData: dict["exception_data"])
    }
}

// MARK: - 错误类型（对应需求 13 的错误提示分类）

enum GuavaError: Error {
    case network(underlying: String)      // 网络失败
    case apiUnavailable                   // API 不可用
    case tokenExpired                     // Token 过期
    case needAuth                         // 需要授权
    case noPermission(message: String)    // 套餐无权限
    case clientVersion(message: String)   // 客户端版本被服务端拒绝（30003 等）
    case noNodes                          // 没有节点
    case server(code: Int, message: String)
}

// MARK: - HTTP 客户端

enum HTTP {
    static func request(url: URL,
                        method: String = "GET",
                        body: [String: Any]? = nil,
                        extraHeaders: [String: String] = [:],
                        timeout: TimeInterval = 20) async throws -> (Int, Data) {
        var req = URLRequest(url: url)
        req.timeoutInterval = timeout
        req.cachePolicy = .reloadIgnoringLocalCacheData
        req.httpMethod = method

        // 原 App 的请求头集合
        req.setValue(ClientConfig.clientLanguage, forHTTPHeaderField: "X-Client-Language")
        req.setValue(ClientConfig.agentFlag, forHTTPHeaderField: "X-Client-Agent-Flag")
        req.setValue(DeviceIdentity.deviceId, forHTTPHeaderField: "X-Client-Device-Id")
        req.setValue("application/json", forHTTPHeaderField: "Accept")

        // 用户授权 Token（X-Client-Token）
        if let token = KeychainStore.shared.authToken, !token.isEmpty {
            req.setValue(token, forHTTPHeaderField: "X-Client-Token")
        }
        // 客户端签名（X-Client-App-Token）
        if let appToken = ClientSigner.appToken(), !appToken.isEmpty {
            req.setValue(appToken, forHTTPHeaderField: "X-Client-App-Token")
        }
        for (k, v) in extraHeaders {
            req.setValue(v, forHTTPHeaderField: k)
        }
        if let body {
            req.setValue("application/json", forHTTPHeaderField: "Content-Type")
            req.httpBody = try JSONSerialization.data(withJSONObject: body)
        }

        let (data, response) = try await URLSession.shared.data(for: req)
        let status = (response as? HTTPURLResponse)?.statusCode ?? 0
        return (status, data)
    }
}

// MARK: - API 编排

final class GuavaAPIService {
    private(set) var apiRoots: [String] = []
    private(set) var discoveredConfigURLs: [String] = []
    private(set) var isManualMode = false
    private var isResolving = false

    func resetAPIRoots() {
        apiRoots = []
        discoveredConfigURLs = []
        isManualMode = false
    }

    func setManualRoots(_ roots: [String]) {
        apiRoots = roots
        isManualMode = true
    }

    /// 读取公开配置入口，解析出 API 根（主 api_url1，备 api_url2，再备 cloud 镜像）
    func resolveAPIRoots() async -> [String] {
        if !apiRoots.isEmpty { return apiRoots }
        if isResolving { return apiRoots }
        isResolving = true
        defer { isResolving = false }

        var roots: [String] = []
        var sources = ClientConfig.apiConfigURLs
        var index = 0

        while index < sources.count && roots.isEmpty {
            let urlString = sources[index]
            index += 1
            guard let url = URL(string: urlString) else { continue }
            do {
                let (_, data) = try await HTTP.request(url: url, timeout: 12)
                guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                      let dataDict = json["data"] as? [String: Any] else { continue }
                for key in ClientConfig.configRootKeys {
                    if let s = dataDict[key] as? String, !s.isEmpty {
                        let t = s.trimmingCharacters(in: .whitespaces)
                        if !roots.contains(t) { roots.append(t) }
                    }
                }
                // cloud_* 指向配置镜像，追加为备用配置源
                for key in ClientConfig.configCloudKeys {
                    if let s = dataDict[key] as? String, !s.isEmpty {
                        let t = s.trimmingCharacters(in: .whitespaces)
                        if !sources.contains(t) { sources.append(t) }
                        if !discoveredConfigURLs.contains(t) { discoveredConfigURLs.append(t) }
                    }
                }
            } catch {
                continue
            }
        }

        if roots.isEmpty {
            // 配置入口全部失败，兜底用逆向实测到的根
            roots = ["https://api.ibale.cc", "http://18.183.229.229:8078/ep1011"]
        }
        apiRoots = roots
        return roots
    }

    // MARK: 请求 + 错误映射

    private func callAPI(_ path: String,
                         method: String = "GET",
                         body: [String: Any]? = nil,
                         requiresAuth: Bool = false) async throws -> GuavaEnvelope {
        let roots = apiRoots.isEmpty ? await resolveAPIRoots() : apiRoots
        guard !roots.isEmpty else { throw GuavaError.apiUnavailable }
        if requiresAuth, KeychainStore.shared.authToken == nil {
            throw GuavaError.needAuth
        }

        var lastNetworkError: String?
        for root in roots {
            let base = root.hasSuffix("/") ? String(root.dropLast()) : root
            guard let url = URL(string: base + path) else { continue }
            do {
                let (status, data) = try await HTTP.request(url: url, method: method, body: body)
                if status == 401 || status == 403 {
                    throw GuavaError.needAuth
                }
                if let envelope = GuavaEnvelope.parse(data) {
                    return envelope
                }
                if status >= 400 {
                    lastNetworkError = "HTTP \(status)"
                    continue
                }
                // 200 但无法解析为业务信封：尝试下一个根
                lastNetworkError = "响应格式异常"
                continue
            } catch let error as GuavaError {
                throw error
            } catch {
                lastNetworkError = (error as? URLError)?.localizedDescription ?? error.localizedDescription
            }
        }
        throw GuavaError.network(underlying: lastNetworkError ?? "未知网络错误")
    }

    static func ensureSuccess(_ env: GuavaEnvelope) throws {
        switch env.code {
        case 0:
            return
        case 30003:
            let msg = env.message.isEmpty ? "服务端要求升级客户端" : env.message
            throw GuavaError.clientVersion(message: msg)
        case 30001, 4011:
            throw GuavaError.needAuth
        case 30002:
            throw GuavaError.tokenExpired
        case 4000, 4001, 4002, 4003:
            throw GuavaError.noPermission(message: env.message)
        default:
            throw GuavaError.server(code: env.code, message: env.message)
        }
    }

    static func extractToken(from env: GuavaEnvelope) -> String? {
        if let s = env.data as? String, !s.isEmpty { return s }
        if let d = env.data as? [String: Any] {
            for key in ["token", "auth_token", "access_token", "login_token", "key"] {
                if let s = d[key] as? String, !s.isEmpty { return s }
                if let n = d[key] as? NSNumber { return n.stringValue }
            }
        }
        return nil
    }

    // MARK: 登录 / 授权

    func checkIsRegistered(email: String) async throws -> Bool {
        let env = try await callAPI("/user/account/check-is-registed", method: "POST", body: ["email": email])
        try Self.ensureSuccess(env)
        if let d = env.data as? [String: Any] {
            for key in ["is_registed", "registed", "registered", "is_registered"] {
                if let b = d[key] as? Bool { return b }
            }
        }
        throw GuavaError.server(code: env.code, message: "服务端未返回注册状态")
    }

    func sendVerifyCode(email: String) async throws {
        // 逆向线索：6 位数字验证码。接口名在不同版本略有差异，依次尝试。
        let candidates = ["/user/account/send-code",
                          "/user/account/send-verify-code",
                          "/user/account/get-verify-code"]
        var lastError: GuavaError = .apiUnavailable
        for path in candidates {
            do {
                let env = try await callAPI(path, method: "POST", body: ["email": email])
                try Self.ensureSuccess(env)
                return
            } catch let error as GuavaError {
                lastError = error
            } catch {
                lastError = .network(underlying: error.localizedDescription)
            }
        }
        throw lastError
    }

    func login(email: String, password: String) async throws -> String {
        let env = try await callAPI("/user/account/login",
                                    method: "POST",
                                    body: ["email": email, "password": password],
                                    requiresAuth: false)
        try Self.ensureSuccess(env)
        guard let token = Self.extractToken(from: env) else {
            throw GuavaError.server(code: env.code, message: "登录成功但响应中没有 Token")
        }
        KeychainStore.shared.authToken = token
        return token
    }

    func loginByCode(email: String, code: String) async throws -> String {
        let env = try await callAPI("/user/account/login-by-code",
                                    method: "POST",
                                    body: ["email": email, "code": code],
                                    requiresAuth: false)
        try Self.ensureSuccess(env)
        guard let token = Self.extractToken(from: env) else {
            throw GuavaError.server(code: env.code, message: "登录成功但响应中没有 Token")
        }
        KeychainStore.shared.authToken = token
        return token
    }

    // MARK: 节点获取

    func fetchNodes() async throws -> [NodeItem] {
        do {
            let env = try await callAPI("/node/home", method: "GET")
            try Self.ensureSuccess(env)
            let items = NodeParser.extract(from: env.data)
            if !items.isEmpty { return items }
        } catch let error as GuavaError {
            throw error
        } catch {
            throw GuavaError.network(underlying: (error as? URLError)?.localizedDescription ?? error.localizedDescription)
        }
        // 备用接口
        let env = try await callAPI("/user/node/collect", method: "GET")
        try Self.ensureSuccess(env)
        let items = NodeParser.extract(from: env.data)
        if items.isEmpty { throw GuavaError.noNodes }
        return items
    }

    /// Token 过期时用 Keychain 中保存的合法凭据自动重登（需求 5）
    func fetchNodesWithAutoRelogin() async throws -> [NodeItem] {
        do {
            return try await fetchNodes()
        } catch GuavaError.tokenExpired {
            guard let email = KeychainStore.shared.email,
                  let password = KeychainStore.shared.password else {
                KeychainStore.shared.authToken = nil
                throw GuavaError.needAuth
            }
            _ = try await login(email: email, password: password)
            return try await fetchNodes()
        }
    }

    /// 订阅链接（原 App /node/settings 相关）
    func fetchSubscribeURL() async throws -> String? {
        let env = try await callAPI("/node/settings/subscribe", method: "GET")
        try Self.ensureSuccess(env)
        if let s = env.data as? String, s.hasPrefix("http") { return s }
        if let d = env.data as? [String: Any] {
            for key in ["url", "url1", "subscribe_url", "subscribe", "link"] {
                if let s = d[key] as? String, s.hasPrefix("http") { return s }
            }
        }
        return nil
    }
}

// MARK: - 节点模型

struct NodeItem: Identifiable, Hashable {
    let id = UUID()
    let name: String
    let scheme: String
    let value: String
}

// MARK: - 节点解析（支持 Quantumult X 常见节点 / 订阅格式）

enum NodeParser {
    /// Quantumult X / Surge / Clash 通用 URI 前缀
    private static let uriSchemes = ["vmess://", "vless://", "trojan://", "ss://", "ssr://", "socks5://"]

    static func isNodeURI(_ line: String) -> Bool {
        let lower = line.lowercased()
        if uriSchemes.contains(where: { lower.hasPrefix($0) }) { return true }
        // http:// 节点必须有 user:pass@host:port 形态（区别于普通链接）
        if lower.hasPrefix("http://") { return line.contains("@") }
        return false
    }

    /// 从原始文本解析（手动订阅 / 接口返回的字符串体）
    static func parse(_ text: String, depth: Int = 0) -> [NodeItem] {
        if depth > 6 { return [] }
        var result: [NodeItem] = []
        let lines = text.components(separatedBy: .newlines)
        for line in lines {
            let t = line.trimmingCharacters(in: .whitespacesAndNewlines)
            if isNodeURI(t) { result.append(makeItem(line: t)) }
        }
        if !result.isEmpty { return dedupe(result) }

        // Base64 整包订阅
        let compact = text.replacingOccurrences(of: "\n", with: "")
            .replacingOccurrences(of: "\r", with: "")
        if let decoded = base64Decode(compact), !decoded.isEmpty {
            let nested = parse(decoded, depth: depth + 1)
            if !nested.isEmpty { return nested }
        }

        // Clash YAML 轻量提取
        return parseClash(text)
    }

    /// 从 JSON data 字段递归提取（适应未知的返回结构）
    static func extract(from data: Any?) -> [NodeItem] {
        var result: [NodeItem] = []
        walk(data, into: &result, depth: 0)
        return dedupe(result)
    }

    static func makeItem(line: String) -> NodeItem {
        let scheme = line.components(separatedBy: "://").first?.lowercased() ?? "node"
        let name = extractName(from: line, scheme: scheme)
        return NodeItem(name: name, scheme: scheme, value: line)
    }

    // MARK: - 内部

    private static func walk(_ value: Any?, into result: inout [NodeItem], depth: Int) {
        if depth > 8 { return }
        if let str = value as? String {
            let lines = str.components(separatedBy: .newlines)
            var added = false
            for line in lines {
                let t = line.trimmingCharacters(in: .whitespacesAndNewlines)
                if isNodeURI(t) {
                    result.append(makeItem(line: t))
                    added = true
                }
            }
            if !added, let decoded = base64Decode(str), decoded != str {
                walk(decoded, into: &result, depth: depth + 1)
            }
        } else if let arr = value as? [Any] {
            for item in arr { walk(item, into: &result, depth: depth + 1) }
        } else if let dict = value as? [String: Any] {
            if let item = makeStructuredItem(dict) {
                result.append(item)
                return
            }
            // 常见结构：{"name": "香港01", "value": "vmess://..."} 或 {"name": ..., "url": "trojan://..."}
            let dictName = firstString(dict, keys: ["name", "remark", "title", "ps"])
            var foundURI = false
            for (_, v) in dict {
                guard let s = v as? String, isNodeURI(s) else { continue }
                if let name = dictName, !name.isEmpty {
                    let scheme = s.components(separatedBy: "://").first?.lowercased() ?? "node"
                    result.append(NodeItem(name: name, scheme: scheme, value: s))
                } else {
                    result.append(makeItem(line: s))
                }
                foundURI = true
            }
            if foundURI { return }
            for (_, v) in dict { walk(v, into: &result, depth: depth + 1) }
        }
    }

    /// 结构化节点（server/host + port + 类型字段）重建 URI
    private static func makeStructuredItem(_ dict: [String: Any]) -> NodeItem? {
        let host = firstString(dict, keys: ["server", "host", "addr", "address", "hostname"])
        guard let host = host, !host.isEmpty else { return nil }
        let port: String
        if let p = firstString(dict, keys: ["port"]) { port = p }
        else if let n = firstNumber(dict, keys: ["port"]) { port = String(n) }
        else { return nil }

        let type = firstString(dict, keys: ["type", "protocol"])?.lowercased() ?? ""
        let name = firstString(dict, keys: ["name", "remark", "title", "ps"]) ?? "\(host):\(port)"
        let method = firstString(dict, keys: ["method", "cipher"]) ?? "chacha20-ietf-poly1305"
        let password = firstString(dict, keys: ["password", "pwd"])
        let uuid = firstString(dict, keys: ["uuid", "id", "passwd", "password"])
        let sni = firstString(dict, keys: ["sni", "servername"])
        let tls = (dict["tls"] as? Bool) == true
            || firstString(dict, keys: ["tls"]) == "1"
            || firstString(dict, keys: ["tls"])?.lowercased() == "true"

        let safeName = urlEncodeFragment(name)

        switch type {
        case "trojan":
            let pwd = password ?? uuid ?? ""
            var s = "trojan://\(pwd)@\(host):\(port)"
            var query: [String] = []
            if tls { query.append("security=tls") }
            if let sni = sni, !sni.isEmpty { query.append("sni=\(sni)") }
            if !query.isEmpty { s += "?" + query.joined(separator: "&") }
            s += "#" + safeName
            return NodeItem(name: name, scheme: "trojan", value: s)
        case "ss", "shadowsocks":
            let pwd = password ?? ""
            let base = Data("\(method):\(pwd)".utf8).base64EncodedString()
            let s = "ss://\(base)@\(host):\(port)#\(safeName)"
            return NodeItem(name: name, scheme: "ss", value: s)
        default:
            // vmess / ssr 等结构化字段复杂，原样 URI 优先
            return nil
        }
    }

    private static func extractName(from line: String, scheme: String) -> String {
        if let hash = line.split(separator: "#", maxSplits: 1).last,
           !hash.isEmpty,
           let decoded = String(hash).removingPercentEncoding,
           !decoded.isEmpty {
            return decoded
        }
        switch scheme {
        case "vmess":
            let b64 = String(line.dropFirst("vmess://".count))
            if let data = Data(base64Encoded: b64, options: .ignoreUnknownCharacters),
               let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
               let ps = json["ps"] as? String, !ps.isEmpty {
                return ps
            }
            return "vmess 节点"
        case "ss":
            let rest = String(line.dropFirst("ss://".count))
            if let hostPort = rest.split(separator: "@").last, !hostPort.isEmpty {
                return String(hostPort)
            }
            return rest
        case "trojan", "vless":
            let rest = String(line.dropFirst("\(scheme)://".count))
            if let hostPort = rest.split(separator: "@").last {
                return String(hostPort.split(separator: "#").first ?? hostPort)
            }
            return rest
        case "ssr":
            let rest = String(line.dropFirst("ssr://".count))
            if let data = Data(base64Encoded: rest, options: .ignoreUnknownCharacters),
               let decoded = String(data: data, encoding: .utf8),
               let hostPart = decoded.split(separator: ":").first {
                return String(hostPart)
            }
            return rest
        default:
            return String(line.prefix(48))
        }
    }

    private static func parseClash(_ text: String) -> [NodeItem] {
        var result: [NodeItem] = []
        let lines = text.components(separatedBy: .newlines)
        var currentName: String?
        var currentBlock = ""
        for line in lines {
            let trimmed = line.trimmingCharacters(in: .whitespaces)
            if trimmed.hasPrefix("- name:") {
                if let name = currentName, !currentBlock.isEmpty {
                    result.append(NodeItem(name: name, scheme: "clash", value: currentBlock))
                }
                currentName = trimmed
                    .replacingOccurrences(of: "- name:", with: "")
                    .trimmingCharacters(in: .whitespaces)
                    .trimmingCharacters(in: CharacterSet(charactersIn: "\"'"))
                currentBlock = line
            } else if currentName != nil,
                      trimmed.hasPrefix("server:") || trimmed.hasPrefix("port:")
                        || trimmed.hasPrefix("type:") || trimmed.hasPrefix("password:")
                        || trimmed.hasPrefix("uuid:") || trimmed.hasPrefix("cipher:") {
                currentBlock += " | " + trimmed
            }
        }
        if let name = currentName, !currentBlock.isEmpty {
            result.append(NodeItem(name: name, scheme: "clash", value: currentBlock))
        }
        return result
    }

    private static func base64Decode(_ s: String) -> String? {
        guard !s.isEmpty, s.rangeOfCharacter(from: .whitespacesAndNewlines) == nil else { return nil }
        let padded = s.count % 4 == 0 ? s : s + String(repeating: "=", count: 4 - s.count % 4)
        guard let data = Data(base64Encoded: padded, options: .ignoreUnknownCharacters) else { return nil }
        return String(data: data, encoding: .utf8)
    }

    private static func dedupe(_ items: [NodeItem]) -> [NodeItem] {
        var seen = Set<String>()
        return items.filter { seen.insert($0.value).inserted }
    }

    private static func firstString(_ dict: [String: Any], keys: [String]) -> String? {
        for key in keys {
            if let s = dict[key] as? String, !s.isEmpty { return s }
        }
        return nil
    }

    private static func firstNumber(_ dict: [String: Any], keys: [String]) -> Int? {
        for key in keys {
            if let n = dict[key] as? Int { return n }
            if let n = dict[key] as? Double { return Int(n) }
            if let n = dict[key] as? NSNumber { return n.intValue }
        }
        return nil
    }

    private static func urlEncodeFragment(_ s: String) -> String {
        s.addingPercentEncoding(withAllowedCharacters: .urlFragmentAllowed) ?? s
    }
}
