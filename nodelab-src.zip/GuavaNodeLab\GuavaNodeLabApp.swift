import SwiftUI

@main
struct GuavaNodeLabApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
