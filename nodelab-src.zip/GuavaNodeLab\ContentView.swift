//
//  ContentView.swift
//  Node Lab
//
//  UI 层：首页极简（一个醒目的【获取节点】按钮）→ 节点列表（数量/名称/内容）
//  → 【复制节点】【复制订阅】。设置页包含账号授权（Keychain 保存）与手动来源。
//

import SwiftUI
import UIKit

// MARK: - 主界面

@MainActor
struct ContentView: View {
    @StateObject private var model = NodeLabModel()
    @State private var showSettings = false

    var body: some View {
        NavigationStack {
            ZStack {
                Color(.systemGroupedBackground).ignoresSafeArea()
                ScrollView {
                    VStack(spacing: 18) {
                        heroButton
                        statusCard
                        if model.nodes.isEmpty {
                            placeholderCard
                        } else {
                            resultCard
                        }
                        copyCard
                    }
                    .padding(20)
                }
            }
            .navigationTitle("Node Lab")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showSettings = true } label: {
                        Image(systemName: "gearshape.fill")
                    }
                }
            }
            .sheet(isPresented: $showSettings) {
                SettingsView(model: model)
            }
        }
    }

    // MARK: 醒目【获取节点】

    private var heroButton: some View {
        Button {
            Task { await model.getNodes() }
        } label: {
            ZStack {
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .fill(
                        LinearGradient(colors: [Color.accentColor, Color.accentColor.opacity(0.65)],
                                       startPoint: .topLeading,
                                       endPoint: .bottomTrailing)
                    )
                    .shadow(color: Color.accentColor.opacity(0.35), radius: 14, y: 7)
                HStack(spacing: 12) {
                    if model.isLoading {
                        ProgressView().tint(.white)
                    } else {
                        Image(systemName: "arrow.down.circle.fill")
                            .font(.title)
                            .foregroundStyle(.white.opacity(0.9))
                    }
                    Text(model.isLoading ? "获取中…" : "获取节点")
                        .font(.title.bold())
                        .foregroundStyle(.white)
                }
                .padding(.vertical, 24)
            }
            .frame(maxWidth: .infinity)
        }
        .buttonStyle(.plain)
        .disabled(model.isLoading)
    }

    // MARK: 状态与错误

    private var statusCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 8) {
                Image(systemName: model.statusIcon)
                    .foregroundStyle(model.statusColor)
                Text(model.statusText)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(model.statusColor)
                Spacer()
            }
            if !model.detail.isEmpty {
                Text(model.detail)
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .textSelection(.enabled)
            }
        }
        .padding(16)
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }

    private var placeholderCard: some View {
        VStack(spacing: 8) {
            Image(systemName: "list.bullet.rectangle.portrait")
                .font(.system(size: 34))
                .foregroundStyle(.tertiary)
            Text("点击上方「获取节点」开始")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 36)
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }

    // MARK: 节点结果（数量 / 名称 / 内容）

    private var resultCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Label("节点列表", systemImage: "list.bullet.rectangle")
                    .font(.headline)
                Spacer()
                Text("共 \(model.nodes.count) 个节点")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)
            }
            ForEach(Array(model.nodes.prefix(50))) { node in
                NodeRow(node: node)
            }
            if model.nodes.count > 50 {
                Text("… 共 \(model.nodes.count) 个，列表仅显示前 50 个")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(16)
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }

    // MARK: 复制

    private var copyCard: some View {
        HStack(spacing: 12) {
            Button {
                model.copyNodes()
            } label: {
                Label("复制节点", systemImage: "doc.on.doc")
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 13)
            }
            .buttonStyle(.borderedProminent)
            .disabled(model.nodes.isEmpty)

            Button {
                model.copySubscription()
            } label: {
                Label("复制订阅", systemImage: "link.badge.plus")
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 13)
            }
            .buttonStyle(.bordered)
            .disabled(model.nodes.isEmpty && model.subscribeURL == nil)
        }
        .font(.subheadline.weight(.semibold))
    }
}

// MARK: - 节点行

struct NodeRow: View {
    let node: NodeItem

    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Text(node.scheme.uppercased())
                .font(.caption2.bold())
                .padding(.horizontal, 7)
                .padding(.vertical, 3)
                .background(Color.accentColor.opacity(0.12))
                .clipShape(Capsule())
            VStack(alignment: .leading, spacing: 3) {
                Text(node.name)
                    .font(.subheadline.weight(.medium))
                    .lineLimit(1)
                Text(node.value)
                    .font(.caption2.monospaced())
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
                    .textSelection(.enabled)
            }
            Spacer(minLength: 0)
        }
        .padding(.vertical, 4)
    }
}

// MARK: - 视图模型

@MainActor
final class NodeLabModel: ObservableObject {
    enum StatusLevel {
        case idle, loading, success, error
    }

    @Published var isLoading = false
    @Published var statusText = "就绪"
    @Published var statusLevel: StatusLevel = .idle
    @Published var detail = ""
    @Published var nodes: [NodeItem] = []
    @Published var subscribeURL: String?
    @Published var discoveredAPIs: [String] = []
    @Published var apiRoots: [String] = []
    @Published var manualSource = ""
    @Published var isLoggedIn = false
    @Published var loggedInEmail: String?

    let service = GuavaAPIService()

    // MARK: 状态外观

    var statusColor: Color {
        switch statusLevel {
        case .idle: return .secondary
        case .loading: return .orange
        case .success: return .green
        case .error: return .red
        }
    }

    var statusIcon: String {
        switch statusLevel {
        case .idle: return "circle"
        case .loading: return "arrow.triangle.2.circlepath"
        case .success: return "checkmark.circle.fill"
        case .error: return "exclamationmark.triangle.fill"
        }
    }

    // MARK: 主流程

    func getNodes() async {
        guard !isLoading else { return }
        isLoading = true
        statusLevel = .loading
        statusText = "获取中…"
        detail = ""
        nodes = []
        subscribeURL = nil
        defer { isLoading = false }

        let manual = manualSource.trimmingCharacters(in: .whitespacesAndNewlines)
        if !manual.isEmpty {
            await fetchFromManualSource(manual)
            return
        }
        if service.isManualMode {
            service.resetAPIRoots()
        }

        do {
            let roots = await service.resolveAPIRoots()
            apiRoots = roots
            discoveredAPIs = service.discoveredConfigURLs
            guard !roots.isEmpty else {
                setError(.apiUnavailable, message: "无法从公开配置入口解析出 API 地址。可在设置中填写你自己的订阅或 API 地址。")
                return
            }
            let items = try await service.fetchNodesWithAutoRelogin()
            guard !items.isEmpty else {
                setError(.noNodes, message: "服务器返回成功但没有可用节点。")
                return
            }
            nodes = items
            statusLevel = .success
            statusText = "获取成功 · \(items.count) 个节点"
            detail = "来源：\(roots.joined(separator: " / "))"
            if let sub = try? await service.fetchSubscribeURL() {
                subscribeURL = sub
            }
            syncAuthState()
        } catch let error as GuavaError {
            apply(error)
        } catch {
            setError(.network(underlying: error.localizedDescription), message: nil)
        }
    }

    private func fetchFromManualSource(_ source: String) async {
        let lower = source.lowercased()
        if lower.hasPrefix("http://") || lower.hasPrefix("https://") {
            // 订阅链接或 API 根
            guard let url = URL(string: source) else {
                setError(.apiUnavailable, message: "地址格式不正确。")
                return
            }
            do {
                let (_, data) = try await HTTP.request(url: url)
                let text = String(data: data, encoding: .utf8) ?? ""
                let items = NodeParser.parse(text)
                if items.isEmpty {
                    // 可能是 API 根：尝试作为根地址调用节点接口
                    service.setManualRoots([source])
                    try await fetchNodesFromService()
                } else {
                    nodes = items
                    subscribeURL = source
                    statusLevel = .success
                    statusText = "获取成功 · \(items.count) 个节点"
                    detail = "来源：手动订阅"
                }
            } catch let error as GuavaError {
                apply(error)
            } catch {
                setError(.network(underlying: error.localizedDescription), message: nil)
            }
            return
        }
        // 单条节点 URI
        if NodeParser.isNodeURI(source) {
            nodes = [NodeParser.makeItem(line: source)]
            statusLevel = .success
            statusText = "获取成功 · 1 个节点"
            detail = "来源：手动节点"
        } else {
            setError(.apiUnavailable, message: "无法识别手动来源。请填写订阅链接、API 根地址或节点 URI。")
        }
    }

    private func fetchNodesFromService() async throws {
        let items = try await service.fetchNodesWithAutoRelogin()
        guard !items.isEmpty else { throw GuavaError.noNodes }
        nodes = items
        statusLevel = .success
        statusText = "获取成功 · \(items.count) 个节点"
        detail = "来源：手动 API 根"
        if let sub = try? await service.fetchSubscribeURL() {
            subscribeURL = sub
        }
    }

    // MARK: 复制

    func copyNodes() {
        guard !nodes.isEmpty else { return }
        UIPasteboard.general.string = nodes.map(\.value).joined(separator: "\n")
        statusLevel = .success
        statusText = "已复制 \(nodes.count) 个节点"
    }

    func copySubscription() {
        if let sub = subscribeURL {
            UIPasteboard.general.string = sub
            statusLevel = .success
            statusText = "已复制订阅链接"
            detail = sub
        } else if !nodes.isEmpty {
            UIPasteboard.general.string = nodes.map(\.value).joined(separator: "\n")
            statusLevel = .success
            statusText = "已复制节点列表（无独立订阅链接）"
        }
    }

    // MARK: 登录状态

    func syncAuthState() {
        isLoggedIn = KeychainStore.shared.authToken != nil
        loggedInEmail = KeychainStore.shared.email
    }

    func logout() {
        KeychainStore.shared.clearAuth()
        syncAuthState()
    }

    // MARK: 错误处理（需求 13 的六类提示）

    private func setError(_ error: GuavaError, message: String?) {
        statusLevel = .error
        switch error {
        case .network(let underlying):
            statusText = "网络失败"
            detail = message ?? "无法连接服务器（\(underlying)）。请检查网络后重试。"
        case .apiUnavailable:
            statusText = "API 不可用"
            detail = message ?? "所有 API 地址均无响应或返回格式异常。"
        case .tokenExpired:
            statusText = "Token 已过期"
            detail = message ?? "已尝试自动重新登录。若仍失败，请在设置中重新登录。"
        case .needAuth:
            statusText = "需要授权"
            detail = message ?? "该接口需要账号授权。请在设置中登录你的账号（凭据仅保存在本机 Keychain）。"
        case .noPermission(let msg):
            statusText = "套餐无权限"
            detail = msg.isEmpty ? (message ?? "当前账号 / 套餐无权访问该节点。") : msg
        case .clientVersion(let msg):
            statusText = "API 不可用"
            detail = msg.isEmpty ? (message ?? "服务端要求升级客户端。") : msg
        case .noNodes:
            statusText = "没有节点"
            detail = message ?? "接口返回成功，但没有可用节点。"
        case .server(let code, let msg):
            statusText = "服务器返回错误（\(code)）"
            detail = msg.isEmpty ? "未知错误" : msg
        }
    }

    private func apply(_ error: GuavaError) {
        setError(error, message: nil)
    }

    func errorText(_ error: GuavaError) -> String {
        switch error {
        case .network(let u): return "网络失败：\(u)"
        case .apiUnavailable: return "API 不可用"
        case .tokenExpired: return "Token 已过期"
        case .needAuth: return "需要授权"
        case .noPermission(let m): return m.isEmpty ? "套餐无权限" : m
        case .clientVersion(let m): return m.isEmpty ? "客户端版本过低" : m
        case .noNodes: return "没有节点"
        case .server(let c, let m): return "服务器错误（\(c)）：\(m)"
        }
    }
}

// MARK: - 设置页（账号授权 + 手动来源 + 诊断）

@MainActor
struct SettingsView: View {
    @ObservedObject var model: NodeLabModel
    @Environment(\.dismiss) private var dismiss

    @State private var email = ""
    @State private var password = ""
    @State private var code = ""
    @State private var isWorking = false
    @State private var actionDetail = ""

    var body: some View {
        NavigationStack {
            Form {
                // 账号授权
                Section {
                    if model.isLoggedIn {
                        LabeledContent("已登录账号", value: model.loggedInEmail ?? "—")
                        Button("退出登录", role: .destructive) {
                            model.logout()
                            actionDetail = "已退出登录，本机 Keychain 中的凭据已清除。"
                        }
                    } else {
                        TextField("邮箱", text: $email)
                            .textInputAutocapitalization(.never)
                            .keyboardType(.emailAddress)
                            .autocorrectionDisabled()
                        SecureField("密码", text: $password)
                        HStack {
                            Button("获取验证码") {
                                Task { await sendCode() }
                            }
                            .font(.footnote)
                            .disabled(email.isEmpty || isWorking)
                            TextField("验证码（可选）", text: $code)
                                .keyboardType(.numberPad)
                        }
                        Button {
                            Task { await login() }
                        } label: {
                            if isWorking {
                                ProgressView()
                            } else {
                                Text("登录")
                            }
                        }
                        .disabled(email.isEmpty || password.isEmpty || isWorking)
                    }
                    if !actionDetail.isEmpty {
                        Text(actionDetail)
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                } header: {
                    Text("账号授权（可选）")
                } footer: {
                    Text("登录后 Token 与凭据仅保存在本机 Keychain。Token 过期时 App 会自动使用已保存的凭据重新登录，无需每次手动填写。")
                }

                // 手动来源
                Section {
                    TextField("订阅链接 / API 根地址 / 节点 URI", text: $model.manualSource)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.URL)
                        .autocorrectionDisabled()
                    Button("使用此来源") {
                        dismiss()
                        Task { await model.getNodes() }
                    }
                    .disabled(model.manualSource.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                } header: {
                    Text("手动来源")
                } footer: {
                    Text("可填写你自己的合法订阅链接、API 根地址或单条节点 URI。留空则使用原 App 的公开 API 流程。")
                }

                // 诊断
                Section {
                    LabeledContent("设备 ID", value: DeviceIdentity.deviceId)
                    if !model.apiRoots.isEmpty {
                        LabeledContent("API 根", value: model.apiRoots.joined(separator: " / "))
                    }
                    if !model.discoveredAPIs.isEmpty {
                        DisclosureGroup("配置入口") {
                            ForEach(model.discoveredAPIs, id: \.self) { url in
                                Text(url)
                                    .font(.caption.monospaced())
                            }
                        }
                    }
                } header: {
                    Text("诊断")
                }

                // 说明
                Section {
                    Text("本工具仅负责获取、解析与复制节点，不含 VPN 内核。所有请求复用你账号的合法授权，不修改设备身份、不伪造版本、不绕过服务端限制。")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("设置")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("完成") { dismiss() }
                }
            }
            .onAppear {
                model.syncAuthState()
                email = KeychainStore.shared.email ?? ""
            }
        }
    }

    private func login() async {
        isWorking = true
        actionDetail = ""
        defer { isWorking = false }
        do {
            if !code.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                _ = try await model.service.loginByCode(email: email, code: code)
            } else {
                _ = try await model.service.login(email: email, password: password)
            }
            KeychainStore.shared.email = email
            KeychainStore.shared.password = password
            model.syncAuthState()
            actionDetail = "登录成功，Token 已保存到 Keychain。"
        } catch let error as GuavaError {
            actionDetail = model.errorText(error)
        } catch {
            actionDetail = "登录失败：\(error.localizedDescription)"
        }
    }

    private func sendCode() async {
        isWorking = true
        actionDetail = "正在发送验证码…"
        defer { isWorking = false }
        do {
            try await model.service.sendVerifyCode(email: email)
            actionDetail = "验证码已发送。"
        } catch let error as GuavaError {
            actionDetail = model.errorText(error)
        } catch {
            actionDetail = "发送失败：\(error.localizedDescription)"
        }
    }
}
