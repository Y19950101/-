# Node Lab 1.0.1（番石榴 API 客户端改造工程）

基于用户交付的 NodeLab Xcode 工程，按《番石榴-1.0.3.ipa》的**实际 API / 认证流程**改造完成。
App 只负责：**获取 → 解析 → 复制节点**（不含 VPN 内核、无广告、无复杂注册流程）。

---

## 〇、没有 Mac？用 GitHub Actions 免费自动生成 IPA（推荐）

本机是 Windows 时无法运行 Xcode，但已配好一条免费构建通道
（`.github/workflows/build-ipa.yml`，macOS 虚拟机 + xcodebuild）：

1. 打开 https://github.com → 新建一个**私有仓库**（New repository）；
2. 进入仓库 → `Add file ▸ Upload files` → 把本工程整个文件夹（含
   `.github`、`GuavaNodeLab`、`GuavaNodeLab.xcodeproj`）拖进去 → Commit；
3. 仓库页 `Actions` 标签会自动开始构建（或手动点 `Run workflow`）；
4. 构建结束（约 3–5 分钟）后，在 Actions 运行记录里下载
   **`NodeLab-unsigned.ipa`**（未签名 IPA，arm64）；
5. 把 IPA 导入**全能签** → 选择你的证书签名 → 安装到 iPhone。

> 私有仓库每月 2000 分钟免费构建时长（macOS 按 10 倍计，约 200 分钟），
> 构建一次约 5 分钟，足够长期使用。产物未签名，由全能签在设备侧完成签名，
> 无需 Apple Developer 付费证书。

## 一、分析结论（对原 IPA 的逆向 + 实测）

| 项目 | 结论 |
|---|---|
| 应用形态 | Flutter 应用，Bundle ID `com.balecc.iosv2`，显示名 BaleccVPN，版本 1.0.3 |
| API 配置入口（4 个，均可用） | `https://raw.githubusercontent.com/Faalemon/cloud/main/api-1011fsl.json`<br>`https://api.ibale.cc/s3c/api-1011fsl.json`<br>`https://cts.ibl1.site:31011/s3c/api-1011fsl.json`<br>`https://ibale.lat/s3c/api-1011fsl.json` |
| 配置返回字段 | `{"code":0,"message":"","data":{"api_url1":"https://api.ibale.cc","api_url2":"http://18.183.229.229:8078/ep1011","cloud_url":...,"cloud_url_f1":...,"cloud_url_f2":...}}` |
| API Root | **动态轮换**：实测发现 `api_url1` 每次请求都变化（`api.ibale.cc` / `slapi.xn--…` 域名 / `43.207.122.237:8078` 等），因此 App 必须每次启动动态读取配置，不能写死 |
| 节点接口 | `/node/home`（主）、`/user/node/collect`（备）、`/node/settings`（设置/订阅） |
| 账号接口 | `/user/account/login`、`/user/account/check-is-registed`、`/user/app` |
| 请求头 | `X-Client-App-Token`（客户端签名）、`X-Client-Token`（用户授权）、`X-Client-Device-Id`、`X-Client-Language`、`X-Client-Agent-Flag` |
| 响应信封 | 成功 `{"code":0,"message":"","data":{...}}`；失败含 `code` 与 `message` |
| 登录流程 | 邮箱 + 密码 / 邮箱 + 6 位验证码 → 设备绑定 → 节点列表（与工程内字符串线索一致） |
| 节点格式 | vmess / vless / trojan / ss / ssr / socks5 URI、Base64 订阅包、Clash YAML |

### ⚠️ 当前服务端状态（重要）

实测（2026-09-30）：**官方服务端对所有缺少有效 `X-Client-App-Token` 的请求统一返回
`code=30003「版本过低请升级: https://ibalevv.com/」`**（备用根返回 `https://edgelem.shop/`）。
即 **1.0.3 客户端本身当前也被服务端版本门槛拦截**——原 App 现在打开同样会提示升级。

该门槛在**客户端签名层**（不是 UA/版本头/账号层），必须携带官方当前版本的有效
`X-Client-App-Token` 才能通过。静态逆向未能在二进制中直接恢复生成该 Token 所需的
明文密钥（二进制里的十六进制串 `MinghuaQu` 等经与 jruby-openssl / pointycastle
比对确认是**椭圆曲线参数 seed**，不是密钥）。

**处理方式（遵守"不伪造"约束）**：App 不伪造版本号 / 设备身份 / 授权凭据。
- 未配置客户端常量时：App 如实显示服务端返回的 30003 与官方升级地址；
- 配置了官方当前版本常量后：走正常官方 API 通道，登录 → Token（Keychain）→ 节点；
- **手动来源始终可用**：在设置里填入你自己账号的合法订阅链接 / API 根地址即可直接获取节点。

---

## 二、如何补齐客户端常量（可选，约 15 分钟）

> 仅当你希望 App 直连官方 API 通道时执行。使用你自己的合法账号，不涉及任何绕过。

1. 准备一台装了 Linux 或 WSL 的电脑，安装 [blutter](https://github.com/worawit/blutter)；
2. 从 App Store / 官方渠道下载**官方当前版本** IPA（与你账号正在用的版本一致）；
3. 解包后运行：
   ```bash
   blutter_frida_ios.py dump /path/to/Payload/Runner.app/Frameworks/App.framework/App out/
   ```
4. 在 `out/dart_objs/*.dart` 中找到 `Encrypt` 类，读取：
   - `_aesKey` 的取值 → 填入 `GuavaCore.swift` 的 `ClientConfig.aesKey`
   - `_appKey`（或 `_getAppKeyP1/P2` 的拼接结果）→ 填入 `ClientConfig.appKey`
   - 若 `generateAppToken()` 的拼接/加密方式与工程内 `ClientSigner.appToken()`
     不同，按实际修改该方法（注释已标明）。
5. 重新编译安装即可。

备用方案：用抓包工具（Stream / Charles / mitmproxy）代理手机上官方 App 的流量，
观察 `X-Client-App-Token` 的**生成规律**（该值含时间戳、每次不同，所以仍需要第 4 步的密钥）。

---

## 三、编译 → Archive → Export IPA → 安装

> 本工程在 Windows 环境下完成，**未在 Xcode 中实机编译验证**（无 macOS/Xcode）。
> 代码按 iOS 16.0 / Swift 5 标准编写，无第三方依赖，直接打开即可编译。

1. 把 `GuavaNodeLab.xcodeproj` 用 Xcode 14+ 打开（建议 Xcode 15/16）；
2. 选中 Target `NodeLab` → `Signing & Capabilities`：
   - `Team` 选择你自己的 Apple Developer 账号；
   - 如需修改 Bundle ID，直接在 `Signing` 里改（`Info.plist` 已用
     `$(PRODUCT_BUNDLE_IDENTIFIER)` 跟随，改一处即可）；
3. 选择真机（不要选 Simulator）→ `Product ▸ Archive`；
4. `Window ▸ Organizer` → 选中归档 → `Distribute App` → `Development` /
   `Ad Hoc`（按你的证书类型选择）→ Export 得到 `.ipa`；
5. 用**全能签**（或爱思助手等）签名安装到你的 iPhone：
   - 全能签导入 `.ipa`，选择你的 Apple ID 证书签名，安装即可。

> 无开发者证书也能用免费 Apple ID（个人团队）签：Xcode 里选你的 Apple ID 作为 Team，
> 首次真机运行需在手机上信任开发者证书。

---

## 四、功能与代码结构

```
GuavaNodeLab/
├── GuavaNodeLabApp.swift   # App 入口
├── ContentView.swift       # UI：首页【获取节点】→ 节点列表 → 复制节点/复制订阅；设置（登录/手动来源/诊断）
├── GuavaCore.swift         # 实现层（见下）
└── Info.plist              # Bundle ID 跟随构建变量；已放行 http（备用 API 根）
```

`GuavaCore.swift`：
- `ClientConfig`：客户端常量（**需要按需修改的唯一位置**）
- `KeychainStore`：用户授权 Token / 邮箱 / 密码 / 设备 ID，全部 Keychain 加密保存
- `DeviceIdentity`：本 App 自己的持久化设备 ID（首次生成，不伪造）
- `AESCryptor`：AES-CBC + PKCS7 + Base64（与原始 App 加密组件一致）
- `ClientSigner`：`X-Client-App-Token` 生成（结构同原 `Encrypt.generateAppToken()`）
- `HTTP`：统一请求头（X-Client 系列）
- `GuavaAPIService`：配置解析 → API 根故障切换 → 登录/验证码 → 节点获取 →
  Token 过期自动重登 → 订阅链接
- `NodeParser`：vmess/vless/trojan/ss/ssr/socks5 URI、Base64 订阅、Clash YAML、
  未知 JSON 结构递归提取、结构化节点重建

错误提示映射：
| 场景 | 提示 |
|---|---|
| 网络失败 | 「网络失败」+ 原因 |
| API 不可用 | 「API 不可用」 |
| Token 过期 | 「Token 已过期」+ 自动用 Keychain 凭据重登 |
| 需要授权 | 「需要授权」→ 引导到设置登录 |
| 套餐无权限 | 「套餐无权限」+ 服务端消息 |
| 没有节点 | 「没有节点」 |
| 服务端业务错误 | 显示 code + 服务端 message（如 30003 版本过低） |

---

## 五、合规与边界

- 不修改设备身份、不伪造新用户、不绕过套餐/流量/支付/设备授权；
- 私人凭据不硬编码：所有用户凭据仅保存在本机 Keychain；
- 无广告、无 VPN 内核、无复杂注册流程；
- 若官方服务端要求更新客户端，App 会如实提示，不会伪装版本号绕过。
